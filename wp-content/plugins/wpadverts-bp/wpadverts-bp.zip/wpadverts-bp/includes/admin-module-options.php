<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

include_once dirname( ADVERTS_PATH ) . '/wpadverts-bp/includes/admin-pages.php';

adext_bp_page_options();